

// -------------------------------------------------------
// Assignment #1
// Written by: Shadi Jiha #40131284
// For COMP 248 Section (your section) � Fall 2019
//
// This program prints how to make coffee at work using programming
// --------------------------------------------------------


public class JavaProgramming {

	public static void main(String[] args) {
		
		// Printing statement
		System.out.println("Welcome to to COMP 248 Java Programming!");
		System.out.print("Let's use programming to have some coffee when you work!\n"
				+ "while (working)\n"
				+ "{\n"
				+ "	CoffeeMug.drink();\n"
				+ "	workTask.Execute();\n"
				+ "	if (coffeeMug == \"Empty\")\n"
				+ "	{\n"
				+ "		if (coffeePot  == \"Empty\")\n"
				+ "			coffeePot.Make();\n"
				+ "		coffeeMug.Refill();\n"
				+ "	}\n"
				+ "	Enjoy your coffee\n"
				+ "}");

	}

}
