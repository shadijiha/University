

// -------------------------------------------------------
// Assignment #1
// Written by: Shadi Jiha #40131284
// For COMP 248 Section EC C � Fall 2019
//
// This program converters a 5 digit input into a valid time (hh:mm:ss)
// --------------------------------------------------------

import java.util.Scanner;
import java.math.*;

public class TimeConverter {

	public static void main(String[] args) {		
		
		/* Declaring main variables */
		int userInput = 0;			// This variable stores the user input
		int swappedInputInt = 0;	// This variable stores the user input with first and last digit swapped
		Scanner scan = new Scanner(System.in);	// This variable store the main System in scan to get user input
		boolean timeIsCorrect = true;	// This is a flag variable that will allow the program to know if the time is correct or not
		final int MIN_IN_HOURS = 60;	// This constant stores the number of minutes in an hour
		final int SEC_IN_MIN = 60;		// This constant stores the number of seconds in an minutes
		
		// Display welcome message
		System.out.println("**********************************\n"
				+ "Welcome to Time Converter Program\n"
				+ "**********************************\n");
		
		// Collect data from user
		System.out.print("Please enter the seconds which will be converted: ");
		userInput = scan.nextInt();
		
		// Evaluate the input (if the time is correct or not)
		if (userInput > 86400)	{
			
			timeIsCorrect = false;

			/* Swapping digits */
		    int firstDigit, lastDigit, digits;
		    
		    // Find last digit
		    lastDigit = userInput % 10; 

		    // Total number of digit - 1
		    digits = (int) Math.log10(userInput); 
		    
		    // Find first digit
		    firstDigit = (int) (userInput / Math.pow(10, digits));

		    swappedInputInt  = lastDigit;
		    swappedInputInt *= (int) Math.round(Math.pow(10, digits));
		    swappedInputInt += userInput % ((int)Math.round(Math.pow(10, digits)));
		    swappedInputInt -= lastDigit;
		    swappedInputInt += firstDigit;
			
		} else	{			
			timeIsCorrect = true;			
		}
		
		// Calculating the original set of hours, minutes and seconds
		int hours = userInput / (MIN_IN_HOURS * SEC_IN_MIN);
		int minutes = (userInput % (MIN_IN_HOURS * SEC_IN_MIN)) / MIN_IN_HOURS;
		int seconds = userInput % SEC_IN_MIN;
		
		/* Displaying either the correct or incorrect time entered */
		if (!timeIsCorrect)	{
			
			// Display result to user
			System.out.printf("\nThe correspond hours, minutes, seconds is %d hrs, %d mins, %d secs", hours, minutes, seconds);
			System.out.println("\n\nThere is no valid time of your input.");
			System.out.printf("\nThe swapped sequence of the input is:%d", swappedInputInt);
			
			// Calculate the new set of hours, minutes and seconds
			int swappedHours = swappedInputInt / (MIN_IN_HOURS * SEC_IN_MIN);
			int swappedMinutes = (swappedInputInt % (MIN_IN_HOURS * SEC_IN_MIN)) / MIN_IN_HOURS;
			int swappedSeconds = swappedInputInt % SEC_IN_MIN;
			
			
			System.out.printf("\n\nThe correspond hours, minutes, seconds is %d hrs, %d mins, %d secs", swappedHours, swappedMinutes, swappedSeconds);
			
			
		} else	{
			
			// Print the result of a correct time entered			
			System.out.printf("\nThe correspond hours, minutes, seconds is %d hrs, %d mins, %d secs", hours, minutes, seconds);
			System.out.printf("\n\nThe valid time is: %s:%s:%s", 
					hours < 10 ? "0" + Integer.toString(hours) : Integer.toString(hours), 
					minutes < 10 ? "0" + Integer.toString(minutes) : Integer.toString(minutes), 
					seconds < 10 ? "0" + Integer.toString(seconds) : Integer.toString(seconds));	
		}
		
		// Goodbye statement
		System.out.println("\n\nThank you for using the Time Converter Program!");
		
		scan.close();
		
	}

}
