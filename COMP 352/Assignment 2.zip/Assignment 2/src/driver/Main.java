package driver;

import calculator.*;

public class Main {

	public static void main(String[] args) {
		// write your code here


		// Calculator
		var result = new Calculator().calculate("3 * ( 2 ^ 2 )");

		Calculator.fromFile("test.txt");


	}

}
